package main.java.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Producto {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private String nombre;
	
	@Column
	private String descripcion;
	
	private LocalDate fecahALta;
	
	private LocalDate fechaBaja;
	
	public Producto(String string, String string2, LocalDate localDate) {
		super();
		this.nombre = string;
		this.descripcion = string2;
		this.fecahALta = localDate;
		this.fechaBaja = null;
	}

	public long getId() {
		return id;
	}
	
	
	
}
