package main.java.com.service;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Producto;

public class ServicioPersistenciaProductoJava {
//persistir
	public void guardar(Producto p) {
		//creamos y comenzamos transaccion con base de datos 
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
	
		session.persist(p);
		
		session.getTransaction().commit();
		
		session.close();
	}
	
	//Actualizar
	public void actualizar(Producto p, long id) {
		
		
	
	}
	//leer
	
	public void Podructo() {
		Session session = ConnectionUtil.getSessionFactory().openSession();
	}
	
	public Producto obtenerID (long id) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		var producto = session.find(Producto.class,1L);
		
		assert(producto!=null && producto.getId()==1L);
		
		session.close();
		return producto;
		
	}

    //ELiminar
	public void eliminar(Producto p) {	
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		session.remove(session.find(Producto.class,1L));
		session.getTransaction().commit();
		
		session.close();
		
		
	}
	
	
}
