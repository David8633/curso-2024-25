package main.java;



import org.hibernate.SessionFactory;
import main.java.com.hibernate.*;

public class Principal {

	public static void main(String[] args) {
		SessionFactory sT = ConnectionUtil.getSessionFactory();
	}
}
