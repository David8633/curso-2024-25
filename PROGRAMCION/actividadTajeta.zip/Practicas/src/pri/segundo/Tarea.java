package pri.segundo;

import java.util.Objects;

public class Tarea implements Comparable<Tarea>{
	
	private Integer id;
	private int prioridad;
	private int duracion;
	
	public Tarea(int prioridad, int duracion) {
		super();
		this.prioridad = prioridad;
		this.duracion = duracion;
	}

	@Override
	public int hashCode() {
		return Objects.hash(duracion, id, prioridad);
	}

	
	public boolean equals(Tarea obj) {
		return obj!=null && obj instanceof Tarea && this.id.equals(obj.id);
	}

	@Override
	public int compareTo(Tarea o) {
		if(id.isBefore(o.id))
		return 0;
	}
	
	
	
	
	
	
	
}
