package com.model;

public class LimiteGastosExcepcion extends Exception {

	public static final String MENSAJE_DEFECTO = "Su limite es inferior a 0";
	
	public LimiteGastosExcepcion() {
		System.out.println(MENSAJE_DEFECTO);
	}

	public LimiteGastosExcepcion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LimiteGastosExcepcion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public LimiteGastosExcepcion(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LimiteGastosExcepcion(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
