package com.model;

public class Usuario implements Comparable<Usuario> {

	private Integer CalificacionCrediticia;
	private TaretaCredito TaretaCredito;
	
	public Usuario() {
		super();
		this.CalificacionCrediticia=10;
		this.TaretaCredito = new TaretaCredito();
		
	}
	
	public void saldar() {
		this.TaretaCredito.setLimiteGastado(0);
	}

	public void compra(double dinero) throws LimiteGastosExcepcion {
	this.TaretaCredito.setDineroGastado(dinero);
	try {
		double resultado = TaretaCredito.getLimiteGastado()-TaretaCredito.getDineroGastado();
		if(resultado<0) {
			throw new LimiteGastosExcepcion();
		}
	}catch(LimiteGastosExcepcion e){
		TaretaCredito.setLimiteGastado(200);
		setCalificacionCrediticia();
		System.out.println("Tu Limite de Gastos es ahora de "+this.TaretaCredito.getLimiteGastado());
		}
	}
	
	@Override
	public int compareTo(Usuario o) {
		return this.CalificacionCrediticia.compareTo(o.CalificacionCrediticia);
	}

	public Integer getCalificacionCrediticia() {
		return CalificacionCrediticia;
	}

	public void setCalificacionCrediticia() {
		CalificacionCrediticia --;
	}

	public TaretaCredito getTaretaCredito() {
		return TaretaCredito;
	}

	public void setTaretaCredito(TaretaCredito taretaCredito) {
		TaretaCredito = taretaCredito;
	}

	
	public String toString() {
		return "Tu usuario tiene " + this.getCalificacionCrediticia() + " el limite de la tarjeta de credito es " + this.getTaretaCredito();
	}
}
