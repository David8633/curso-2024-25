package com.model;

public class TaretaCredito  {

	private double LimiteGastado;
	private double DineroGastado;
	
	public TaretaCredito() {
		super();
		this.LimiteGastado=2000;
		this.DineroGastado=0;
	}

	public double getLimiteGastado() {
		return LimiteGastado;
	}

	public void setLimiteGastado(double limiteGastado) {
		LimiteGastado = limiteGastado;
	}

	public double getDineroGastado() {
		return DineroGastado;
	}

	public void setDineroGastado(double dineroGastado) {
		DineroGastado += dineroGastado;
	}
	
public String toString() {
	return "Tiene de Limite Gastado " +this.getLimiteGastado() + " y Dinero gastado = " + this.getDineroGastado();
}
	
	}


