package com;

import java.util.Arrays;

import com.model.LimiteGastosExcepcion;
import com.model.Usuario;

public class Main {

	public static void main(String[] args) throws LimiteGastosExcepcion {

		Usuario[] u = new Usuario[2];
		
		
		
		
		Usuario u1 = new Usuario();
		Usuario u2 = new Usuario();
		
		u[0]= u1;
		u[1]=u2;
		u1.compra(265.98);
		u1.compra(126.50);
		u1.compra(562.95);
		u1.compra(999.99);
		u1.compra(600.43);
		u1.compra(211.2);
		u1.compra(300);
		
		Arrays.sort(u);
		System.out.println(Arrays.toString(u));
	}

}
